After do
  $driver.reset if $driver
end
